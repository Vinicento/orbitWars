def agent(obs):
    return []
